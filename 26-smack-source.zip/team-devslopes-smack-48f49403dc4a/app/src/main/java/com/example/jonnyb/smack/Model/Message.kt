package com.example.jonnyb.smack.Model

/**
 * Created by jonnyb on 9/9/17.
 */
class Message constructor(val message: String, val userName: String, val channelId: String,
                          val userAvatar: String, val userAvatarColor: String,
                          val id: String, val timeStamp: String)